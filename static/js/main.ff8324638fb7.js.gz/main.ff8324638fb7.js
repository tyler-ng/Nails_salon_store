// javascript for additional functions
setTimeout(function () {
  $('#message').fadeOut('slow');
}, 5000);

// $(document).ready(function () {
//   var date_input = $('input[name="date"]'); //our date input has the name "date"
//   var container =
//     $('.bootstrap-iso form').length > 0
//       ? $('.bootstrap-iso form').parent()
//       : 'body';
//   var options = {
//     format: 'yyyy-mm-dd',
//     startDate: new Date(),
//     container: container,
//     todayHighlight: true,
//     autoclose: true,
//   };
//   date_input.datepicker(options);
// });

// $('#timepicker').datetimepicker({
//   timepicker: true,
//   datepicker: false,
//   format: 'H:i',
//   // value: '09:45',
//   step: 5,
//   allowTimes: [],
// });
